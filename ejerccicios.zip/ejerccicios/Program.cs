﻿/*Console.Write("Por favor, ingresa tu nombre: ");
int numero = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Hola, " + numero + "! Bienvenido.");*/
/* 1. Verifica si un número es positivo.
int numero = Convert.ToInt32(Console.ReadLine());
if (numero > 0)
{
    Console.Write("ES POSITIVO"); 
}
else
{
    Console.Write("NO ES POSITIVO"); 
}*/

/*2. Verifica si un número es negativo

Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero < 0)
{
    Console.Write("ES NEGATIVO"); 
}
else
{
    Console.Write(" ES POSITIVO"); 
}*/

/*3Comprueba si un número es par.
Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero % 2 == 0)
{
    Console.Write(" ES PAR"); 
}
else
{
    Console.Write("NO  ES PAR"); 
}*/


/*4. Comprueba si un número es impar.
Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero % 2 == 0)
{
    Console.Write(" ES PAR"); 
}
else
{
    Console.Write("ES IMPAR"); 
}*/
/*5. Determina si un número es múltiplo de 5.
Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero % 5 == 0)
{
    Console.Write("ES DIVISIBLE POR 5"); 
}
else
{
    Console.Write("NO ES DIVISIBLE POR 5"); 
}*/

/*6. Verifica si un número es divisible entre 3.
Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero % 3 == 0)
{
    Console.Write("ES DIVISIBLE POR 3"); 
}
else
{
    Console.Write("NO ES DIVISIBLE POR 3"); 
}*/
/*7. Determina si un número es mayor que 100.
Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero > 100)
{
    Console.Write(" ES MAYOR QUE 100"); 
}
else
{
    Console.Write("NO  ES MAYOR QUE 100"); 
}*/
/*8. Verifica si un número es menor que -50.
Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero < -50)
{
    Console.Write(" ES menor QUE -50"); 
}
else
{
    Console.Write("  ES MAYOR QUE -50"); 
}*/
/*9. Comprueba si un número está en el rango de 20 a 50.
Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero >= 20 && numero <= 50)
{
    Console.Write("esta en el rango de 20 a 50"); 
}
else
{
    Console.Write("no esta en el rango de 20 a 50"); 
}*/
/*10. Determina si un número es igual a 0.
Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero == 0)
{
    Console.Write("es 0"); 
}
else
{
    Console.Write("diferente a 0"); 
}*/
/*11. Verifica si un número es mayor que -10 y menor que 10.
Console.Write("ESCRIBA UN NUMERO"); 
int numero = Convert.ToInt32(Console.ReadLine());
if (numero >= -10 && numero <= 10)
{
    Console.Write("esta en el rango de -10 a 10"); 
}
else
{
    Console.Write("no esta en el rango de -10 a 10"); 
}*/
/*12. Determina si un número es un año bisiesto.
int numero = Convert.ToInt32(Console.ReadLine());
if (numero % 4 == 0  && numero % 100 != 0 || numero % 400 == 0)
{
    Console.Write("es viciesto"); 
}
else
{
    Console.Write("no es viciesto"); 
}*/
/*13. Verifica si una persona es mayor de edad (mayor o igual a 18 años).
int numero = Convert.ToInt32(Console.ReadLine());
if (numero >= 18)
{
    Console.Write("es mayor igual a 18"); 
}
else
{
    Console.Write("no mayor igual a 18"); 
}*/
/*15. Verifica si un número es un cuadrado perfecto.
Console.Write("ESCRIBA UN NUMERO verificaremos si es cuadrado perfecto ");
int numero = Convert.ToInt32(Console.ReadLine());
for (int i = 0; i <= numero; i++)
{
    int comparador = i*i;


    if (comparador == numero)
    {
        Console.Write("es cuadrado perfecto"); 
        
    }
    else if (i == numero)
    {
         Console.Write("no  cuadrado perfecto"); 
    }

}*/
/*16. Determina si un número es un número de Fibonacci.
Console.Write("ESCRIBA UN NUMERO verificaremos si es de fibonachi");
string? valor = Console.ReadLine();
try{
    int numero = Convert.ToInt32(valor);
    int num1 = 0;
    int num2 = 1;
    int comparador = 0;
    while(comparador < numero){
        comparador = num1 + num2;

        if(comparador == numero){
            Console.WriteLine(" es de fibonachi");
             Console.WriteLine(comparador);
        }

        else if(comparador >= numero)
        {
            Console.WriteLine("NOOO es de fibonachi");
            Console.WriteLine(comparador);
        }

        num1 = num2;
        num2 = comparador;
        
    }

}
catch(Exception ex){
    Console.WriteLine("debes introducir un numero entero " + ex.ToString());
}
finally{
     Console.WriteLine(" terminado");
}*/

using Microsoft.VisualBasic;
/*17. Verifica si un número es una potencia de 2
Console.WriteLine("ESCRIBA UN NUMERO verificaremos si potencia de 2");
string? valor = Console.ReadLine();
try{
    int numero = Convert.ToInt32(valor);
    int comparador = 2;
    int Fin = 0;
    while(comparador <= numero){
       
        Console.WriteLine(comparador);

        if(comparador == numero){
            Console.WriteLine(" es potencia de 2");
             Console.WriteLine(comparador);
             Fin  += 1;
        }
        comparador = comparador * 2;
         if(comparador > numero && Fin == 0 )
        {
            Console.WriteLine("NOOO es potencia");
            Console.WriteLine(comparador);
        }
        
        
    }

}
catch(Exception ex){
    Console.WriteLine("debes introducir un numero entero " + ex.ToString());
}
finally{
     Console.WriteLine(" terminado");
}*/


/*18. Determina si un número es un palíndromo.
Console.WriteLine("ESCRIBA UN NUMERO verificaremos si potencia de 2");
string valor = Console.ReadLine();
string comparador  = "";
try{
    
     for (int i = valor.Length - 1; i >= 0; i--)
        {
            
            comparador += valor[i];
        }
        Console.WriteLine(comparador);
        Console.WriteLine(valor);
        if(comparador == valor){
            Console.WriteLine("es palindromo");
        }
}
finally{}*/
/*19. Verifica si una cadena de texto contiene la palabra "JavaScript".
Console.WriteLine("verifiquemos si eesta javascrip como palabra ");
string valor = Console.ReadLine();

try{
        if(valor.Contains("javascrip")){
            Console.WriteLine("con tiene la palabra javascrip");
        }
        else {
            Console.WriteLine("No estasss palabra javascrip");
        }
}
finally{}*/

/*20. Determina si una cadena tiene más de 10 caracteres.
Console.Write("ESCRIBA UNa cadena  verificaremos si tiene mas de 10 caracteres ");
string valor = Console.ReadLine();
if(valor.Length > 10){
    Console.WriteLine("la cadena tiene mas dee 10 caracteres ");
}
*/
Console.WriteLine("verifiquemos si eesta javascrip como palabra ");
string valor = Console.ReadLine();
